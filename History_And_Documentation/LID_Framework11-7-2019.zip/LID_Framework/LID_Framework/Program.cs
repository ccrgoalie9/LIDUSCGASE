﻿using System;
using System.Windows.Forms;

namespace LID_Framework {
    class Program {

        static void Main(string[] args) {
            Console.WriteLine("This project is now for framework use only. Use either the Web App or Windows form to display.");
            Console.ReadKey();
        }
    }
}
