# LIDUSCGASE
NOW WITH GUI!
![The Lid](https://i.pinimg.com/originals/fa/05/c5/fa05c5f91887d39f6d29be0a88cb379f.png)

## About
This is the devlepment github for the progam L.I.D. or Line Iceberg Display. 

1) Downloads current bulletin
2) Strips bulletin format to base form from xml
3) Scrapes Lat/Long sets from lightly modified bulletin in Degree/Minute format
4) Converts Lat/Long sets to Decimal format
5) Creates KML file from Decimal pairs

## Devleopment
Currently in development we have a very redimentrary program that can take live data and create the .kml files.

## Products
.kml files are being produced as of 10/29/2019

## Future
The end goal of this project is to create an AIS message payload that can be used to send to ships at sea. 
